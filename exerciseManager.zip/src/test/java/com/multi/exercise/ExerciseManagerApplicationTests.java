package com.multi.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.multi.management.ExerciseManagerApplication;

@SpringBootTest(classes = ExerciseManagerApplication.class)
class ExerciseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
